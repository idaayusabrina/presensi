import React, { useState } from 'react';
import { Box, Typography, FormControl, FormLabel, Input, Button, Grid, Dialog, DialogTitle, DialogContent, DialogActions, TextField } from '@mui/material';
import EditRoundedIcon from '@mui/icons-material/EditRounded';

export default function Profil({ updateSidebarProfile }) {
  const [profileImage, setProfileImage] = useState("C:/Presensi_Siswa/presensi/public/assets/woo seok7.jpg");
  const [name, setName] = useState("Ryu Sunjae");
  const [email, setEmail] = useState("ryusunjae@gmail.com");
  const [open, setOpen] = useState(false); // State untuk mengatur dialog terbuka atau tidak
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Fungsi untuk menangani perubahan gambar
  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setProfileImage(imageUrl);  // Mengganti gambar profil yang ditampilkan
    }
  };

  // Fungsi untuk membuka input file saat tombol Edit diklik
  const handleEditClick = () => {
    document.getElementById('profileImageInput').click();
  };

  // Fungsi untuk membuka dialog edit password
  const handleOpenDialog = () => {
    setOpen(true);
  };

  // Fungsi untuk menutup dialog edit password
  const handleCloseDialog = () => {
    setOpen(false);
  };

  // Fungsi untuk menyimpan perubahan profil
  const handleSaveProfile = () => {
    // Kirim data profil baru ke sidebar
    updateSidebarProfile({ name, email, profileImage });
    // Lakukan tindakan lain jika diperlukan, seperti menyimpan data ke server
  };

  return (
    <>
      <Box
        sx={{
          width: '100%',
          height: 240,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <Box
          sx={{
            height: 240,
            display: 'flex',
            justifyContent: 'center',
            position: 'relative',
            alignItems: 'center',
            width: 240,
            outline: 'none',
            border: 'none',
            borderRadius: '50%',
          }}>
          <img
            src={profileImage} // Menggunakan state untuk menampilkan gambar profil
            alt="profil"
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              outline: 'none',
              border: 'none',
              borderRadius: '50%',
            }}
          />
          <Box
            sx={{
              position: 'absolute',
              zIndex: 2,
              borderRadius: '50%',
              height: 75,
              width: 75,
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              bottom: 0,
              right: 0,
              border: '4px solid #2D8EFF',
              backgroundColor: 'rgba(255, 255, 255, 0.9)',
              cursor: 'pointer',
            }}
            onClick={handleEditClick} // Saat tombol Edit diklik
          >
            <EditRoundedIcon sx={{ color: '#2D8EFF', fontSize: '40px' }} />
          </Box>
        </Box>
      </Box>

      {/* Input file yang disembunyikan */}
      <input
        id="profileImageInput"
        type="file"
        accept="image/*"
        style={{ display: 'none' }}
        onChange={handleImageChange} // Saat gambar dipilih
      />

      <Box
        sx={{
          width: '100%',
          textAlign: 'center',
          height: 'auto',
        }}>
        <Typography fontSize={30} fontWeight={650}>
          {name}
        </Typography>
        <Typography fontSize={20} fontWeight={300}>
          {email}
        </Typography>
      </Box>

      {/* Box untuk form, ditempatkan di tengah-tengah */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '50vh', // Menjadikan box berada di tengah secara vertikal
        }}
      >
        <FormControl
          sx={{
            px: 6,
            width: { xs: '90%', sm: '70%', md: '50%' }, // Responsive width
            textAlign: 'center',
          }}
        >
          <FormLabel sx={{ fontSize: 21 }}>Nama Lengkap</FormLabel>
          <Input variant="outlined" size="large" value={name} onChange={(e) => setName(e.target.value)} placeholder="Nama Lengkap" sx={{ mb: 3 }} />
          <FormLabel sx={{ fontSize: 21 }}>Email</FormLabel>
          <Input variant="outlined" size="large" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />

          <Grid container spacing={2} sx={{ mt: 4, justifyContent: 'flex-end' }}>
            <Grid item xs={6} sm={3}>
              <Button fullWidth sx={{ fontSize: 15, bgcolor: '#FFAE1F' }} onClick={handleOpenDialog}>
                Edit Password
              </Button>
            </Grid>
            <Grid item xs={6} sm={3}>
              <Button fullWidth color="primary" sx={{ fontSize: 17 }} onClick={handleSaveProfile}>
                Simpan
              </Button>
            </Grid>
          </Grid>
        </FormControl>
      </Box>

      {/* Dialog pop-up untuk edit password */}
      <Dialog open={open} onClose={handleCloseDialog}>
        <DialogTitle>Edit Password</DialogTitle>
        <DialogContent>
          <FormControl sx={{ mb: 3 }} fullWidth>
            <FormLabel>Password Lama</FormLabel>
            <TextField type="password" placeholder="Masukkan password lama" fullWidth value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} />
          </FormControl>
          <FormControl sx={{ mb: 3 }} fullWidth>
            <FormLabel>Password Baru</FormLabel>
            <TextField type="password" placeholder="Masukkan password baru" fullWidth value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
          </FormControl>
          <FormControl fullWidth>
            <FormLabel>Konfirmasi Password Baru</FormLabel>
            <TextField type="password" placeholder="Konfirmasi password baru" fullWidth value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Batal</Button>
          <Button color="primary" onClick={handleCloseDialog}>Simpan</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
