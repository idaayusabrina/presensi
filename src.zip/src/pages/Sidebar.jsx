import * as React from 'react';
import PropTypes from 'prop-types';
import Grid from '@mui/material/Grid';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import { IconButton } from '@mui/material';
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

function Sidebar() {
    const navigate = useNavigate(); // Inisialisasi useNavigate
    const userProfile = {
      name: "Ayukkesanaa",
      avatar: "https://example.com/avatar2.jpg",
      email: "Ayukkesanaa@example.com",
    };

    const handleProfileClick = () => {
      navigate('/profil'); // Navigasi ke halaman profil
    };


  return (
    <Box sx={{ width: '250px', overflow: 'hidden' }}> {/* Lebar box utama disesuaikan */}
      <Grid container>
        <Grid item xs={12}>
          {/* User Profile Section */}
          <Box 
            sx={{ mt: 3, p: 2, bgcolor: 'grey.100', borderRadius: 1, width: '100%', cursor: 'pointer' }} // Menambahkan cursor pointer
            onClick={handleProfileClick} // Menambahkan event handler saat diklik
          >
            <Stack 
              direction="row" 
              spacing={2} 
              alignItems="center" 
              justifyContent="space-between"
              sx={{ width: '100%' }}
            >
              {/* Profil User */}
              <Stack direction="row" spacing={2} alignItems="center">
                <Avatar 
                  src={userProfile.avatar} 
                  alt={userProfile.name} 
                  sx={{ width: 40, height: 40 }}//perkecil avatar
                />
                <Box>
                  <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                    {userProfile.name}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    {userProfile.email}
                  </Typography>
                </Box>
              </Stack>
              
              {/* Tombol Logout */}
              <IconButton 
                size="medium" 
                color="error" 
                sx={{ ml: 2 }} // Menambahkan margin kiri agar icon tidak terlalu dekat
              >
                <LogoutRoundedIcon sx={{ fontSize: 24 }} /> {/* Ukuran ikon disesuaikan */}
              </IconButton>
            </Stack>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
}

Sidebar.propTypes = {
  userProfile: PropTypes.shape({
    avatar: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    email: PropTypes.string.isRequired,
  }).isRequired,
};

export default Sidebar;
